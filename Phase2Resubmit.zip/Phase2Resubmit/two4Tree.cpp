#include <iostream>
using namespace std;

template<typename valuetype>
class CircularDynamicArray {
public:
    int size;
    int cap;
    int front;
    int back;
    valuetype error;
    valuetype* array;

    CircularDynamicArray() {
        array = new valuetype[cap = 2];
        size = 0;
        front = 0;
        back = 0;
    }


    valuetype& operator[](int i) {
        if (i < 0 || i >= size) {
            //cout << "Error: Index is out of bounds." << endl;
            return error;
        }
        return array[(front + i) % cap];
    }


    void addEnd(valuetype v) {
        if (size == cap) {
            int newCap = cap * 2;
            valuetype* newArray = new valuetype[newCap];
            for (int i = 0; i < size; i++) {
                newArray[i] = array[(front + i) % cap];
            }

            front = 0;
            back = size - 1;

            delete[] array;

            array = newArray;
            cap = newCap;
        }

        array[(front + size) % cap] = v;
        size++;
        back = (size - 1) % cap;
    }


    void addFront(valuetype v) {
        if (size == cap) {
            int newCap = cap * 2;
            valuetype* newArray = new valuetype[newCap];

            for (int i = 0; i < size; i++) {
                newArray[i + 1] = array[(front + i) % cap];
            }

            front = 1;
            back = size - 1;

            delete[] array;

            array = newArray;
            cap = newCap;
        }
        front = (front - 1 + cap) % cap;
        array[front] = v;
        size++;
    }
    void delEnd() {
        size--;
        back = (back - 1 + cap) % cap;

        if (size <= (cap / 4) && cap > 2) {
            int newCap = cap / 2;
            valuetype* newArray = new valuetype[newCap];

            for (int i = 0; i < size; i++) {
                newArray[i] = array[(front + i) % cap];
            }

            front = 0;
            back = size - 1;

            delete[] array;

            array = newArray;
            cap = newCap;
        }

    }
    void delFront() {
        front = (front + 1) % cap;
        size--;

        if (size == (cap / 4) && cap > 2) {
            int newCap = cap / 2;
            valuetype* newArray = new valuetype[newCap];

            for (int i = 0; i < size; i++) {
                newArray[i] = array[(front + i) % cap];
            }

            front = 0;
            back = size - 1;

            delete[] array;

            array = newArray;
            cap = newCap;
        }
    }
    int length() {
        return size;
    }
    void clear(){
        delete[] array;
        array = new valuetype[cap = 2];
        size = 0;
        front = 0;
        back = 0;
     }
    ~CircularDynamicArray() {
        delete[] array;
    }
    CircularDynamicArray(const CircularDynamicArray& old) {
        size = old.size;
        cap = old.cap;
        front = old.front;
        back = old.back;
        array = new valuetype[cap];
        for (int i = 0; i < cap; i++) {
            array[i] = old.array[i];
        }
    }
    CircularDynamicArray& operator=(const CircularDynamicArray& rhs) {
        delete[] array;
        size = rhs.size;
        cap = rhs.cap;
        front = rhs.front;
        back = rhs.back;
        array = new valuetype[cap];
        for (int i = 0; i < rhs.cap; i++) {
            array[i] = rhs.array[i];
        }

        return *this;
    }
};


const int t = 2; // degree
template<typename keytype, typename valuetype>
class two4Tree{

    public:

    struct Node {
        int n;
        keytype keys[3];
        CircularDynamicArray<valuetype> vals[3];
        Node* paths[4];
        bool leaf = true;
        int leftSubTrees[3] = {0,0,0};


        Node(bool leaf) {
            this->n = 0;
            this->leaf = leaf;
            for (int i = 0; i < 4; ++i){
                this->paths[i] = nullptr;
            }
            
        }
    };

    void splitchildren(Node* meow, int i, keytype k) {
        Node* x = meow->paths[i];
        Node* u = new Node(x->leaf);
        u->n = 1;
        
        int temp = meow->leftSubTrees[i];

        for (int j = 0; j < 1; j++){
            u->keys[j] = x->keys[j + t];
            u->vals[j] = x->vals[j+t];
            u->leftSubTrees[j] = x->leftSubTrees[j+t];
        }


        if (x->paths[0] != nullptr) {
            for (int j = 0; j < t; j++)
                u->paths[j] = x->paths[j + t];
        }

        x->n = 1;

        for (int j = meow->n; j >= i + 1; --j){
            meow->paths[j + 1] = meow->paths[j];
        }

        meow->paths[i + 1] = u;

        for (int j = meow->n - 1; j >= i; --j){
            meow->keys[j + 1] = meow->keys[j];
            meow->vals[j + 1] = meow->vals[j];
            meow->leftSubTrees[j+1] = meow->leftSubTrees[j];
        }

        meow->keys[i] = x->keys[1];
        meow->vals[i] = x->vals[1];
        meow->leftSubTrees[i] = x->leftSubTrees[0] + x->leftSubTrees[1] + x->vals[0].length();

        int tempLeft = x->vals[0].length() + x->leftSubTrees[0] + x->vals[1].length() + x->leftSubTrees[1] + x->vals[2].length() + x->leftSubTrees[2];

        if(i != meow->n){
            int rightTree = temp - tempLeft;
            meow->leftSubTrees[i+1] = x->leftSubTrees[2] + u->vals[0].length() + rightTree;
        }
        

        meow->n++;
    }

    void insertNonFull(Node* meow, keytype k, valuetype v) {
        int i = meow->n - 1;

        if (meow->paths[0] == nullptr) {
            while (i >= 0 && k < meow->keys[i]) {
                meow->keys[i + 1] = meow->keys[i];
                meow->vals[i + 1] = meow->vals[i];
                meow->leftSubTrees[i+1] = meow->leftSubTrees[i];
                i--;
            }

            if(i >= 0 && meow->keys[i] == k){
                meow->vals[i].addEnd(v);
                return;
            }
            else{
                meow->keys[i + 1] = k;
                meow->vals[i+1].clear();
                meow->vals[i+1].addEnd(v);
                meow->leftSubTrees[i+1] = 0;
                meow->n++;
               
            }
        } 
        else {
            while (i >= 0 && k < meow->keys[i]){
                i--;
            }
            i++;

            if (meow->paths[i]->n == 3) {
                splitchildren(meow, i, k);
                if (k > meow->keys[i])
                    i++;
            }
            if(meow != nullptr){
                for(int a = 0; a < meow->n; a++){
                    if(meow->keys[a] == k){
                        meow->vals[a].addEnd(v);
                        return;
                    }
                }
            }
            
            insertNonFull(meow->paths[i], k,v);
        }
    }

    void insertHelper(Node*& root, keytype k, valuetype v) {
        if (!root) {
            root = new Node(true);
            root->keys[0] = k;
            root->vals[0].addEnd(v);
            root->leftSubTrees[0] = 0;
            root->n = 1;
        } else {
            if (root->n == 3) {
                Node* s = new Node(false);
                s->paths[0] = root;
                splitchildren(s, 0, k);
                root = s;
            }
            insertNonFull(root, k,v);
        }
    }

    Node* root;
    int treeSize = 0;
    int r;

    two4Tree(){
        root = nullptr;
        treeSize = 0;
    }
   
   two4Tree(keytype K[], valuetype V[], float s){
        root = nullptr;
        treeSize = 0;
        for(int i = 0; i < s; i++){
            insert(K[i],V[i]);
        }        
    }

    valuetype *search(keytype k){
        Node* curr = root;

        while (curr != nullptr) {
            
            int i = 0;
            while (i < curr->n && k > curr->keys[i]) {
                i++;
            }

            // found
            if (i < curr->n && k == curr->keys[i]) {
                return &curr->vals[i][0];
            }

            curr = curr->paths[i];
        }

        return nullptr;
    }

    void insert(keytype k, valuetype v){
        treeSize++;  
        insertHelper(root,k,v);
        leftTreeUpdateInsert(k);
    }
    
     keytype selectHelper(Node* curr, int pos) {
        
        int i = 0;
        while(i < curr->n) {
            if (pos > curr->leftSubTrees[i] + curr->vals[i].length()) {
                pos -= curr->leftSubTrees[i] + curr->vals[i].length();
                i++;
            }
            else if (pos == curr->leftSubTrees[i] + curr->vals[i].length()) {
                return curr->keys[i];
            }
            else {
                if (curr->vals[i].length() > 1) {
                    if (pos < curr->leftSubTrees[i] + 1) {
                        return selectHelper(curr->paths[i], pos);
                    }
                    else {
                        return curr->keys[i];
                    }
                }
                else {
                    return selectHelper(curr->paths[i], pos);
                }
            }
        }

        return selectHelper(curr->paths[i], pos);
    }

    keytype select(int pos){
        return selectHelper(root, pos);
    }
 
    int rank(keytype k) {

        r = 0;
        Node* curr = root;
        while (curr != nullptr) {
            int i = 0;

            while (i < curr->n && k > curr->keys[i]) {
                if(curr->vals[i].length() == 0) r+=1;
                r += curr->leftSubTrees[i] + curr->vals[i].length();
                i++;
            }

            // If key is found, return to stop transversing
            if (i < curr->n && k == curr->keys[i]) {
                //cout << root->leftSubTrees[0] << endl << endl;
                if(curr->paths[i] != nullptr){
                    //cout << curr->keys[i] << "'s r before + 1 = " << r + curr->leftSubTrees[i] << endl;
                    return r + curr->leftSubTrees[i] + 1;
                }
                //cout << curr->keys[i] << "'s r before + 1 = " << r << endl;

                return r + 1;
            }

            // Move to the paths if not found
            curr = curr->paths[i];
        }

       return 0;
    }
   
    int duplicates(keytype k){
         Node* curr = root;

        while(curr != nullptr){
            
            int i = 0;
            while (i < curr->n && k > curr->keys[i]) {
                i++;
            }

            // found
            if (i < curr->n && k == curr->keys[i]) {
                
                return curr->vals[i].length(); 
            }

            curr = curr->paths[i];
        }
        return 0;
    }

    int size(){
        return treeSize;
    }

    void preorder(Node* curr){
        if(curr == nullptr) return;

        cout << curr->keys[0] << " ";
        if (curr->n >= 2){
            cout << curr->keys[1] << " "; 
        }
        if (curr->n == 3){
            cout << curr->keys[2] << " ";
        } 
        cout << endl;

        if(curr->n == 1){
        preorder(curr->paths[0]);
        preorder(curr->paths[1]);
        }
        else if(curr->n == 2){
            preorder(curr->paths[0]);
            preorder(curr->paths[1]);
            preorder(curr->paths[2]);
        }
        else if(curr->n == 3){
            preorder(curr->paths[0]);
            preorder(curr->paths[1]);
            preorder(curr->paths[2]);
            preorder(curr->paths[3]);
        }
    }
    void preorder(){
        preorder(root);
    }

    void inorder(){
        inorder(root);
        cout << endl;
    }
    void inorder(Node* curr){

        if(curr != nullptr){
            for(int i = 0; i < curr->n; i++){
                inorder(curr->paths[i]);
                cout << curr->keys[i] << " ";
                if(curr->vals[i].length() > 1){
                    for(int a = 1; a < curr->vals[i].length(); a++){
                        cout << curr->keys[i] << " ";
                    }
                }
            }
            inorder(curr->paths[curr->n]);
        }

    }

    void postorder(){
        postorderHelp(root);
    }
    void postorder(Node *curr){
        if(curr == nullptr) return;

        
        if(curr->n == 1){
            postorderHelp(curr->paths[0]);
            postorderHelp(curr->paths[1]);
        }else if(curr->n == 2){
            postorderHelp(curr->paths[0]);
            postorderHelp(curr->paths[1]);
            postorderHelp(curr->paths[2]);
        }else if(curr->n == 3){
            postorderHelp(curr->paths[0]);
            postorderHelp(curr->paths[1]);
            postorderHelp(curr->paths[2]);
            postorderHelp(curr->paths[3]);
        }
        for(int i = 0; i < curr->n; i++){
            cout << curr->keys[i] << " ";
            
        }
        cout << endl;
    }

    int remove(keytype k){
        int check = removeHelper(root, k);
        if(check != 0){
        leftTreeUpdateRemove(k);
        }
        return check;
    }

    int removeHelper(Node* meow, keytype k){
        if(meow == root && meow->paths[0] == nullptr && meow->n == 1 && k == meow->keys[0]){
            treeSize--;
            meow->vals[0].clear();
            
            root = nullptr;
            meow = nullptr;
            return 1;
        }
        
        int i = 0;
        while (i < meow->n && k > meow->keys[i]) {
            i++;
        }

        if(i == meow->n && i != 1){
            i--;
        }

        if(meow == root && meow->n == 1 && meow->keys[0] != k){
            if(meow->paths[0]->n != 1 && meow->paths[1]->n == 1 && k > meow->keys[0]){
                meow = rotateRight(meow, meow->paths[0], meow->paths[1], i);
                return removeHelper(meow, k);
            }
            else if(meow->paths[0]->n == 1 && meow->paths[1]->n != 1 && k < meow->keys[0]){
                
                meow = rotateLeft(meow, meow->paths[0], meow->paths[1], i);
                return removeHelper(meow, k);
            }
            else if(meow->paths[0]->n == 1 && meow->paths[1]->n == 1){
                meow = merge(meow, meow->paths[0], meow->paths[1], i);
                return removeHelper(meow, k);
            }
            else if(k > meow->keys[0]){
                return removeHelper(meow->paths[1], k);
            }
            else if(k < meow->keys[0]){
                return removeHelper(meow->paths[0], k);
            }

        }
        
        if(meow->keys[i] != k && meow->paths[0] != nullptr && i != meow->n){
                if(meow->paths[i]->n == 1 && meow->paths[i+1]->n == 1){
                    meow = merge(meow, meow->paths[i], meow->paths[i+1], i);
                    return removeHelper(meow, k);
                }
                if(meow->paths[i]->n == 1 && meow->paths[i+1]->n != 1){
                    if(k < meow->keys[i]){
                        meow = rotateLeft(meow, meow->paths[i], meow->paths[i+1], i);
                        return removeHelper(meow, k);
                    }
                    else if(k > meow->keys[i]){
                        return removeHelper(meow->paths[i+1], k);
                    }
                }

                if(meow->paths[i]->n != 1 && meow->paths[i+1]->n == 1){
                    if(k > meow->keys[i]){
                        meow= rotateRight(meow, meow->paths[i], meow->paths[i+1], i);
                        return removeHelper(meow, k);
                    }
                    else if(k < meow->keys[i]){
                        return removeHelper(meow->paths[i], k);
                    }
                }
                
                if(meow->paths[i]->n != 1 && meow->paths[i+1]->n != 1){
                    if(k < meow->keys[i]){
                        return removeHelper(meow->paths[i], k);
                    }
                    else if(k > meow->keys[i]){
                        return removeHelper(meow->paths[i+1], k);
                    }
                }
        }
        
        if(meow->keys[i] != k && meow->paths[0] != nullptr && i == meow->n){
                if(meow->paths[i]->n == 1 && meow->paths[i-1]->n == 1){
                    meow = merge(meow, meow->paths[i], meow->paths[i-1], i);
                    return removeHelper(meow, k);
                }
                if(meow->paths[i]->n == 1 && meow->paths[i-1]->n != 1){
                    if(k < meow->keys[i]){
                        meow = rotateLeft(meow, meow->paths[i], meow->paths[i-1], i);
                        return removeHelper(meow, k);
                    }
                    else if(k > meow->keys[i]){
                        return removeHelper(meow->paths[i-1], k);
                    }
                }

                if(meow->paths[i]->n != 1 && meow->paths[i-1]->n == 1){
                    if(k > meow->keys[i]){
                        meow= rotateRight(meow, meow->paths[i], meow->paths[i-1], i);
                        return removeHelper(meow, k);
                    }
                    else if(k < meow->keys[i]){
                        return removeHelper(meow->paths[i], k);
                    }
                }
               
                if(meow->paths[i]->n != 1 && meow->paths[i-1]->n != 1){
                    if(k < meow->keys[i]){
                        return removeHelper(meow->paths[i], k);
                    }
                    else if(k > meow->keys[i]){
                        return removeHelper(meow->paths[i-1], k);
                    }
                }
        }
        
        if(meow->vals[i].length() > 1 && meow->keys[i] == k){
            meow->vals[i].delFront();
            treeSize--;
            return 1;
        }
        if(meow->keys[i] == k){
            if(meow->paths[0] != nullptr){
                keytype p = predecessor(meow, meow->paths[i], i);
                
                changeTreeFindingPred(root, p);
                Node* predNode = searchNode(root, p);
                int predIndex = 0;
                Node* keyNode = searchNode(root, k);
                int keyIndex = 0;
                for(int a = 0; a < predNode->n; a++){
                    if(p == predNode->keys[a]){
                        predIndex = a;
                        break;
                    }
                }
                for(int a = 0; a < keyNode->n; a++){
                    if(k == keyNode->keys[a]){
                        keyIndex = a;
                        break;
                    }
                }
                
                keytype tempk = keyNode->keys[keyIndex];
                CircularDynamicArray<valuetype> tempCDA = keyNode->vals[keyIndex];
                int tempLeft = keyNode->leftSubTrees[keyIndex];

                keyNode->keys[keyIndex] = predNode->keys[predIndex];
                keyNode->vals[keyIndex] = predNode->vals[predIndex];
                keyNode->leftSubTrees[keyIndex] = predNode->leftSubTrees[predIndex];

                predNode->keys[predIndex] = tempk;
                predNode->vals[predIndex] = tempCDA;
                predNode->leftSubTrees[predIndex] = tempLeft;
                
                deleteKey(predNode, k, predIndex);
                return 1;
            }
            else if(meow->paths[0] == nullptr){
                deleteKey(meow, k, i);
                return 1;
            }
        }

        return 0;
    }

    void changeTreeFindingPred(Node* meow, keytype k){
        int i = 0;
        while (i < meow->n && k > meow->keys[i]) {
            i++;
        }

        if(i == meow->n && i != 1){
            i--;
        }

        if(meow == root && meow->n == 1 && meow->keys[0] != k){
            if(meow->paths[0]->n != 1 && meow->paths[1]->n == 1 && k > meow->keys[0]){
                meow = rotateRight(meow, meow->paths[0], meow->paths[1], i);
                return changeTreeFindingPred(meow, k);
            }
            else if(meow->paths[0]->n == 1 && meow->paths[1]->n != 1 && k < meow->keys[0]){
                
                meow = rotateLeft(meow, meow->paths[0], meow->paths[1], i);
                return changeTreeFindingPred(meow, k);
            }
            else if(meow->paths[0]->n == 1 && meow->paths[1]->n == 1){
                meow = merge(meow, meow->paths[0], meow->paths[1], i);
                return changeTreeFindingPred(meow, k);
            }
            else if(k > meow->keys[0]){
                return changeTreeFindingPred(meow->paths[1], k);
            }
            else if(k < meow->keys[0]){
                return changeTreeFindingPred(meow->paths[0], k);
            }

        }
        
        if(meow->keys[i] != k && meow->paths[0] != nullptr && i != meow->n){
                if(meow->paths[i]->n == 1 && meow->paths[i+1]->n == 1){
                    meow = merge(meow, meow->paths[i], meow->paths[i+1], i);
                    return changeTreeFindingPred(meow, k);
                }
                if(meow->paths[i]->n == 1 && meow->paths[i+1]->n != 1){
                    if(k < meow->keys[i]){
                        meow = rotateLeft(meow, meow->paths[i], meow->paths[i+1], i);
                        return changeTreeFindingPred(meow, k);
                    }
                    else if(k > meow->keys[i]){
                        return changeTreeFindingPred(meow->paths[i+1], k);
                    }
                }

                if(meow->paths[i]->n != 1 && meow->paths[i+1]->n == 1){
                    if(k > meow->keys[i]){
                        meow= rotateRight(meow, meow->paths[i], meow->paths[i+1], i);
                        return changeTreeFindingPred(meow, k);
                    }
                    else if(k < meow->keys[i]){
                        return changeTreeFindingPred(meow->paths[i], k);
                    }
                }
                
                if(meow->paths[i]->n != 1 && meow->paths[i+1]->n != 1){
                    if(k < meow->keys[i]){
                        return changeTreeFindingPred(meow->paths[i], k);
                    }
                    else if(k > meow->keys[i]){
                        return changeTreeFindingPred(meow->paths[i+1], k);
                    }
                }
        }
        
        if(meow->keys[i] != k && meow->paths[0] != nullptr && i == meow->n){
                if(meow->paths[i]->n == 1 && meow->paths[i-1]->n == 1){
                    meow = merge(meow, meow->paths[i], meow->paths[i-1], i);
                    return changeTreeFindingPred(meow, k);
                }
                if(meow->paths[i]->n == 1 && meow->paths[i-1]->n != 1){
                    if(k < meow->keys[i]){
                        meow = rotateLeft(meow, meow->paths[i], meow->paths[i-1], i);
                        return changeTreeFindingPred(meow, k);
                    }
                    else if(k > meow->keys[i]){
                        return changeTreeFindingPred(meow->paths[i-1], k);
                    }
                }

                if(meow->paths[i]->n != 1 && meow->paths[i-1]->n == 1){
                    if(k > meow->keys[i]){
                        meow= rotateRight(meow, meow->paths[i], meow->paths[i-1], i);
                        return changeTreeFindingPred(meow, k);
                    }
                    else if(k < meow->keys[i]){
                        return changeTreeFindingPred(meow->paths[i], k);
                    }
                }
                
                if(meow->paths[i]->n != 1 && meow->paths[i-1]->n != 1){
                    if(k < meow->keys[i]){
                        return changeTreeFindingPred(meow->paths[i], k);
                    }
                    else if(k > meow->keys[i]){
                        return changeTreeFindingPred(meow->paths[i-1], k);
                    }
                }
        }
        
        if(meow->keys[i] == k){
            return;
        }

        return;
    }

    Node *searchNode(Node* curr, keytype k){
        curr = root;

        while (curr != nullptr) {
            
            int i = 0;
            while (i < curr->n && k > curr->keys[i]) {
                i++;
            }

            // found
            if (i < curr->n && k == curr->keys[i]) {
               
                return curr;
            }

            
            curr = curr->paths[i];
        }

        
        return nullptr;
    }

    void deleteKey(Node* meow, keytype k, int i){
        

        if(meow->keys[meow->n - 1] == k){
            meow->n--;
            meow->vals[meow->n-1].clear();
        }

        else if(meow->keys[1] == k && meow->n == 3){
            meow->keys[1] = meow->keys[2];
            meow->vals[1] = meow->vals[2];
            meow->leftSubTrees[1] = meow->leftSubTrees[2];
            meow->n--;
            meow->vals[2].clear();
        }

        else if(meow->keys[0] == k){
            for(int a = 0; a < meow->n - 1; a++){
                meow->keys[a] = meow->keys[a+1];
                meow->vals[a] = meow->vals[a+1];
                meow->leftSubTrees[a] = meow->leftSubTrees[a+1];
            }
            meow->n--;
            
        }
        treeSize--;
    }

    keytype predecessor(Node* meow, Node* x, int i){
        while(x->paths[x->n] != nullptr){
            x = x->paths[x->n];
        }


        return x->keys[x->n-1];
    }

    Node* merge(Node* meow, Node* x, Node* u, int i){
        Node* m = new Node(false); 
        m->keys[0] = x->keys[0];
        m->vals[0] = x->vals[0];
        m->leftSubTrees[0] = x->leftSubTrees[0];

        m->keys[1] = meow->keys[i];
        m->vals[1] = meow->vals[i];
        m->leftSubTrees[1] = meow->leftSubTrees[i] - x->leftSubTrees[0] - x->vals[0].length(); 
        

        m->keys[2] = u->keys[0];
        m->vals[2] = u->vals[0];
        m->leftSubTrees[2] = u->leftSubTrees[0];

        
        m->paths[0] = x->paths[0];
        m->paths[1] = x->paths[1];
        m->paths[2] = u->paths[0];
        m->paths[3] = u->paths[1];
        m->n = 3;
        if(meow == root && meow->n == 1){
            root = m;
            return m;
        }
        
        
        for(int a = i; a < meow->n-1; a++){
            meow->keys[a] = meow->keys[a+1];
            meow->vals[a] = meow->vals[a+1];
            meow->leftSubTrees[a] = meow->leftSubTrees[a+1];
        }
        meow->leftSubTrees[i] = meow->leftSubTrees[i] + m->leftSubTrees[0] + m->vals[0].length() + m->leftSubTrees[1] + m->vals[1].length(); 
        meow->vals[meow->n-1].clear();

        
        meow->paths[i] = m;
        for(int a = i + 1; a < meow->n; a++){
            meow->paths[a] = meow->paths[a+1];
        }
        

        meow->n--;
       

        return m; 
    }

    Node* rotateLeft(Node* meow, Node* x, Node* u, int i){
        
        x->keys[1] = meow->keys[i];
        x->vals[1] = meow->vals[i];
        x->leftSubTrees[1] = meow->leftSubTrees[i] - x->leftSubTrees[0] - x->vals[0].length();
        
        meow->keys[i] = u->keys[0];
        meow->vals[i] = u->vals[0];
        meow->leftSubTrees[i] = x->leftSubTrees[0] + x->vals[0].length() + x->leftSubTrees[1] + x->vals[1].length() + u->leftSubTrees[0];
        meow->leftSubTrees[i+1] -= u->leftSubTrees[0] + u->vals[0].length();
       
        for(int a = 0; a < u->n-1; a++){
            u->keys[a] = u->keys[a+1];
            u->vals[a] = u->vals[a+1];
            u->leftSubTrees[a] = u->leftSubTrees[a+1];
        }
        x->paths[2] = u->paths[0];
        for(int a = 0; a < u->n; a++){
            u->paths[a] = u->paths[a+1];
        }

        u->n--;
        x->n++;
        return meow;
    }

    Node* rotateRight(Node* meow, Node* x, Node* u, int i){
        
        if(i == 1 && meow->n == 1) i = i-1;
        u->keys[1] = u->keys[0];
        u->vals[1] = u->vals[0];
        u->leftSubTrees[1] = u->leftSubTrees[0];
        u->keys[0] = meow->keys[i];
        u->vals[0] = meow->vals[i];
        int temp = 0;
        for(int a = 0; a < x->n; a++){
            temp += x->leftSubTrees[a] + x->vals[a].length();
        }
        u->leftSubTrees[0] = meow->leftSubTrees[i] - temp;
        
        u->paths[2] = u->paths[1];
        u->paths[1] = u->paths[0];
        u->paths[0] = x->paths[x->n];
        
        for(int a = meow->n-1; a > 0; a--){
            meow->keys[a] = meow->keys[a-1];
            meow->vals[a] = meow->vals[a-1];
            meow->leftSubTrees[a] = meow->leftSubTrees[a-1];
        }
        
        meow->keys[i] = x->keys[x->n - 1];
        meow->vals[i] = x->vals[x->n - 1];
        meow->leftSubTrees[i] = temp - x->vals[x->n-1].length();

        

        u->n++;
        x->vals[x->n-1].clear();
        x->n--;




        return meow;
    }

    void leftTreeUpdateInsert(keytype k){
        Node* curr = root;

        while (curr != nullptr) {
            int i = 0;
            while (i < curr->n && k > curr->keys[i]) {
                i++;
            }
            
           
            if(i < curr->n && k != curr->keys[i]){
                curr->leftSubTrees[i] += 1;
                
            }

            
            if (i < curr->n && k == curr->keys[i]) {
                break;
            }

            curr = curr->paths[i];
        }
    }

    void leftTreeUpdateRemove(keytype k){
         Node * curr = root;

        while (curr != nullptr) {
            int i = 0;
            while (i < curr->n && k > curr->keys[i]) {
                i++;
            }
            
            
            if(i < curr->n && k != curr->keys[i]){
                curr->leftSubTrees[i] -= 1;
                if(curr->leftSubTrees[i] < 0) curr->leftSubTrees[i] = 0;
                
            }

            
            if (i < curr->n && k == curr->keys[i]) {
                break;
            }

            curr = curr->paths[i];
        }
    }

    
    two4Tree(const two4Tree &old) {          
        root = nullptr;             
         
        treeSize = 0;
        r = old.r;
        copyTree(old.root, root);        
    }

    two4Tree &operator=(const two4Tree &other) {
        if (this != &other) {
            destroyTree(root);          
            root = nullptr;             
            copyTree(other.root, root); 
            treeSize = other.treeSize;
            r = other.r;
        }
        return *this;
    }
    void copyTree(const Node *src, Node *&rhd) {
        if (src == nullptr)
            return;

        rhd = new Node(src->leaf);
        rhd->n = src->n;
        rhd->leaf = src->leaf;
        for (int i = 0; i < src->n; ++i) {
            rhd->keys[i] = src->keys[i];
            
            rhd->vals[i] = src->vals[i];
            rhd->leftSubTrees[i] = src->leftSubTrees[i];
        }
        rhd->leftSubTrees[src->n] = src->leftSubTrees[src->n];

        for (int i = 0; i < src->n + 1; ++i){
            copyTree(src->paths[i], rhd->paths[i]);
        }
    }

    ~two4Tree() {
        destroyTree(root);
    }

    void destroyTree(Node* meow){
        if(meow != nullptr){
            for(int i = 0; i < meow->n + 1; ++i){
                destroyTree(meow->paths[i]);
            }
            delete meow;
        }
    }

};